import Link from "next/link"
import { ChevronLeft, MoreVertical } from "lucide-react"

interface HeaderProps {
  title: string
  backHref?: string
  showMore?: boolean
}

export function Header({ title, backHref, showMore }: HeaderProps) {
  return (
    <header className="flex items-center justify-between px-4 py-3 bg-white border-b shadow-sm">
      <div className="flex items-center gap-2">
        {backHref && (
          <Link href={backHref} className="text-gray-600 hover:text-gray-800">
            <ChevronLeft className="h-6 w-6" />
          </Link>
        )}
        <h1 className="text-lg font-semibold text-gray-800">{title}</h1>
      </div>
      {showMore && (
        <button className="text-gray-600 hover:text-gray-800">
          <MoreVertical className="h-6 w-6" />
        </button>
      )}
    </header>
  )
}
