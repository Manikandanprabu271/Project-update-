"use client"

import { cn } from "@/lib/utils"

import { Button } from "@/components/ui/button"
import { Plus, Check } from "lucide-react"

interface FabProps {
  icon: "plus" | "check"
  onClick?: () => void
  className?: string
}

export function Fab({ icon, onClick, className }: FabProps) {
  const IconComponent = icon === "plus" ? Plus : Check
  return (
    <Button
      size="icon"
      className={cn(
        "fixed bottom-20 right-4 h-14 w-14 rounded-full shadow-lg bg-primary text-primary-foreground hover:bg-primary/90",
        className,
      )}
      onClick={onClick}
    >
      <IconComponent className="h-8 w-8" />
    </Button>
  )
}
