export const mockStudents = [
  { id: "36", rollNo: "36", name: "KAVIN V S", regNo: "812823205037", studentId: "236053" },
  { id: "37", rollNo: "37", name: "KAVIYARASAN R", regNo: "812823205038", studentId: "236020" },
  { id: "38", rollNo: "38", name: "KISHOR L", regNo: "812823205039", studentId: "236054" },
  { id: "39", rollNo: "39", name: "KUMARAN M", regNo: "812823205040", studentId: "236006" },
  { id: "40", rollNo: "40", name: "LAKSHMANAN S", regNo: "812823205041", studentId: "236052" },
  { id: "41", rollNo: "41", name: "LATHA SREE V B", regNo: "812823205042", studentId: "236055" },
  { id: "42", rollNo: "42", name: "MADAVAN A", regNo: "812823205043", studentId: "236051" },
  { id: "43", rollNo: "43", name: "MAHALAKSHMI K", regNo: "812823205044", studentId: "236056" },
]

export const mockSubjects = [
  { id: "CS3591", name: "CS3591 - CN" },
  { id: "CS3551", name: "CS3551 - DC" },
  { id: "IT3501", name: "IT3501 - FSWD" },
  { id: "CS335", name: "CCS335 - CC" },
]

export const mockCirculars = [
  { id: "1", title: "Exams coming soon!", content: "Exams are coming soon! Be prepared!" },
  { id: "2", title: "Test", content: "Test" },
]

export const mockEvents = [
  { id: "1", title: "Events coming soon!", content: "Events are coming soon! Be ready!", date: "25/12/2024" },
]

export const mockAttendanceSummary = {
  "KAVIN V S": [
    { subject: "CS3591 - CN", present: 0, total: 2, percentage: 0 },
    { subject: "CCS335 - CC", present: 0, total: 1, percentage: 0 },
    { subject: "CS3551 - DC", present: 0, total: 1, percentage: 0 },
    { subject: "Total", present: 0, total: 4, percentage: 0 },
  ],
}

export const mockUserProfile = {
  name: "RAHUL SANJITH N",
  email: "rahul.sanjith@example.com",
  rollNo: "36",
  regNo: "812823205037",
  studentId: "236053",
  academicYear: "2025-2026",
  branch: "Computer Science Engineering",
}
