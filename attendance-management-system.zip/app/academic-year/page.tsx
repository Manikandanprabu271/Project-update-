import { Header } from "@/components/header"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function AcademicYearPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header title="Academic Year" backHref="/classes" />
      <main className="flex-1 p-4 space-y-6">
        <Card className="p-4 rounded-lg shadow-sm bg-white text-center">
          <h3 className="text-sm text-gray-500 mb-1">ACADEMIC YEAR</h3>
          <p className="text-lg font-semibold text-gray-800">2025-2026</p>
        </Card>

        <section className="space-y-3">
          <h3 className="text-lg font-medium text-gray-700">Terms</h3>
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b last:border-b-0">
              <div>
                <p className="font-semibold text-gray-800">25-ODD</p>
                <p className="text-sm text-gray-600">04/08/2025 – 31/12/2025</p>
              </div>
              <Button size="sm" className="bg-primary text-primary-foreground rounded-full px-4 py-1 text-xs">
                Active
              </Button>
            </div>
            <div className="flex items-center justify-between p-4 border-b last:border-b-0">
              <div>
                <p className="font-semibold text-gray-800">26-EVEN</p>
                <p className="text-sm text-gray-600">26/02/2026 – 26/07/2026</p>
              </div>
              {/* No active button for inactive term */}
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}
