import { Header } from "@/components/header"
import { Card } from "@/components/ui/card"
import { mockCirculars, mockEvents } from "@/lib/data"

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header title="Home" />
      <main className="flex-1 p-4 space-y-6">
        <h2 className="text-xl font-semibold text-gray-800">Welcome RAHUL SANJITH N!</h2>

        <section className="space-y-3">
          <h3 className="text-lg font-medium text-gray-700">Circulars</h3>
          {mockCirculars.map((circular) => (
            <Card key={circular.id} className="p-4 rounded-lg shadow-sm bg-white">
              <h4 className="font-semibold text-gray-800">{circular.title}</h4>
              <p className="text-sm text-gray-600">{circular.content}</p>
            </Card>
          ))}
        </section>

        <section className="space-y-3">
          <h3 className="text-lg font-medium text-gray-700">Events</h3>
          {mockEvents.map((event) => (
            <Card key={event.id} className="p-4 rounded-lg shadow-sm bg-white">
              <h4 className="font-semibold text-gray-800">{event.title}</h4>
              <p className="text-sm text-gray-600">{event.content}</p>
              <p className="text-xs text-gray-500 mt-1">{event.date}</p>
            </Card>
          ))}
        </section>
      </main>
    </div>
  )
}
