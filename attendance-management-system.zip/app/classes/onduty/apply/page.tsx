import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { mockStudents } from "@/lib/data"
import { ArrowRightLeft } from "lucide-react"

export default function OnDutyFormApplicationPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header title="OnDuty Form Application" backHref="/classes" />
      <main className="flex-1 p-4 space-y-6">
        <div className="flex items-center justify-center gap-2">
          <Button
            variant="default"
            className="px-6 py-2 rounded-lg shadow-sm bg-primary text-primary-foreground hover:bg-primary/90"
          >
            04/08/2025
          </Button>
          <ArrowRightLeft className="h-5 w-5 text-gray-600" />
          <Button
            variant="default"
            className="px-6 py-2 rounded-lg shadow-sm bg-primary text-primary-foreground hover:bg-primary/90"
          >
            31/12/2025
          </Button>
        </div>

        <section className="space-y-3">
          <h3 className="text-lg font-medium text-gray-700">Attendance Periods</h3>
          <div className="bg-white rounded-lg shadow-sm overflow-x-auto">
            <table className="w-full table-auto">
              <thead>
                <tr className="bg-gray-100 text-sm font-semibold text-gray-600">
                  <th className="p-4 text-left min-w-[100px]">Date</th>
                  <th className="p-4 text-left min-w-[60px]">1</th>
                  <th className="p-4 text-left min-w-[60px]">2</th>
                  <th className="p-4 text-left min-w-[60px]">3</th>
                  <th className="p-4 text-left min-w-[60px]">4</th>
                  <th className="p-4 text-left min-w-[60px]">5</th>
                  <th className="p-4 text-left min-w-[60px]">6</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b last:border-b-0">
                  <td className="p-4 text-sm text-gray-800">04/08/2025</td>
                  <td className="p-4 text-sm text-gray-800">CN</td>
                  <td className="p-4 text-sm text-gray-800">CC</td>
                  <td className="p-4 text-sm text-gray-800">CN</td>
                  <td className="p-4 text-sm text-gray-800">DC</td>
                  <td className="p-4 text-sm text-gray-800">-</td>
                  <td className="p-4 text-sm text-gray-800">-</td>
                </tr>
                {/* More rows can be added here */}
              </tbody>
            </table>
          </div>
        </section>

        <section className="space-y-3">
          <h3 className="text-lg font-medium text-gray-700">Students</h3>
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="grid grid-cols-[0.5fr_1.5fr_1fr] gap-4 p-4 border-b text-sm font-semibold text-gray-600">
              <div>Roll No</div>
              <div>Name</div>
              <div className="text-right">Is Present?</div>
            </div>
            {mockStudents.map((student) => (
              <div
                key={student.id}
                className="grid grid-cols-[0.5fr_1.5fr_1fr] gap-4 p-4 border-b last:border-b-0 items-center"
              >
                <div className="font-semibold text-gray-800">{student.rollNo}</div>
                <div>
                  <p className="font-medium text-gray-800">{student.name}</p>
                  <p className="text-xs text-gray-500">{student.regNo}</p>
                </div>
                <div className="flex justify-end">
                  <Checkbox className="h-6 w-6 rounded-md border-gray-400 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground" />
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  )
}
