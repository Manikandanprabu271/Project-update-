import { Header } from "@/components/header"
import { Fab } from "@/components/fab"
import Link from "next/link"

export default function OnDutySubmissionsPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header title="OnDuty Form Submissions" backHref="/classes" />
      <main className="flex-1 p-4 flex items-center justify-center text-gray-600">No OnDuty Forms</main>
      <Link href="/classes/onduty/apply">
        <Fab icon="plus" />
      </Link>
    </div>
  )
}
