import { Header } from "@/components/header"
import { Card } from "@/components/ui/card"
import { mockAttendanceSummary, mockStudents } from "@/lib/data"

interface AttendanceSummaryPageProps {
  params: {
    studentId: string
  }
}

export default function AttendanceSummaryPage({ params }: AttendanceSummaryPageProps) {
  const student = mockStudents.find((s) => s.id === params.studentId)
  const attendanceData = student ? mockAttendanceSummary[student.name as keyof typeof mockAttendanceSummary] : []

  if (!student) {
    return (
      <div className="flex flex-col min-h-screen bg-gray-50">
        <Header title="Attendance Summary" backHref="/classes" />
        <main className="flex-1 p-4 text-center text-gray-600">Student not found.</main>
      </div>
    )
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header title={student.name} backHref="/classes" />
      <main className="flex-1 p-4 space-y-6">
        <Card className="p-4 rounded-lg shadow-sm bg-white space-y-3">
          <h3 className="text-lg font-medium text-gray-700">Attendance Summary</h3>
          {attendanceData.map((item, index) => (
            <div key={index} className="flex justify-between items-center py-2 border-b last:border-b-0">
              <span className="font-medium text-gray-800">{item.subject}</span>
              <div className="flex items-center gap-2">
                <span className="text-green-600 font-semibold">{item.present}</span>
                <span className="text-gray-600">/</span>
                <span className="text-gray-600">{item.total}</span>
                <span className="text-gray-500">({item.total})</span>
                <span className-="text-red-600 font-semibold">{item.percentage}%</span>
              </div>
            </div>
          ))}
        </Card>

        <section className="space-y-3">
          <h3 className="text-lg font-medium text-gray-700">Detailed Attendance</h3>
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="grid grid-cols-5 gap-4 p-4 border-b text-sm font-semibold text-gray-600">
              <div>Date</div>
              <div>1</div>
              <div>2</div>
              <div>3</div>
              <div>4</div>
            </div>
            {/* Placeholder for detailed attendance table rows */}
            <div className="p-4 text-center text-gray-500">No detailed records available.</div>
          </div>
        </section>
      </main>
    </div>
  )
}
