"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Fab } from "@/components/fab"
import { mockStudents, mockSubjects } from "@/lib/data"
import { cn } from "@/lib/utils"
import { Check } from "lucide-react"

export default function AttendanceEditPage() {
  const [selectedDate, setSelectedDate] = useState("11/08/2025")
  const [selectedPeriod, setSelectedPeriod] = useState("1")
  const [selectedSubject, setSelectedSubject] = useState("CS3591")
  const [attendance, setAttendance] = useState<{ [key: string]: boolean }>({})

  const handleMarkAll = () => {
    const newAttendance: { [key: string]: boolean } = {}
    const allPresent = Object.values(attendance).every((val) => val) // Check if all are already marked present
    mockStudents.forEach((student) => {
      newAttendance[student.id] = !allPresent // Toggle all
    })
    setAttendance(newAttendance)
  }

  const handleAttendanceChange = (studentId: string, isChecked: boolean) => {
    setAttendance((prev) => ({
      ...prev,
      [studentId]: isChecked,
    }))
  }

  const handleSubmit = () => {
    console.log("Attendance Submitted:", {
      date: selectedDate,
      period: selectedPeriod,
      subject: selectedSubject,
      attendance: attendance,
    })
    alert("Attendance submitted! Check console for details.")
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header title="Attendance Edit" backHref="/classes" />
      <main className="flex-1 p-4 space-y-6">
        <section className="space-y-3">
          <h3 className="text-lg font-medium text-gray-700">Date</h3>
          <Button
            variant="outline"
            className="w-fit px-6 py-2 rounded-lg shadow-sm bg-white text-primary border-primary hover:bg-primary/10"
          >
            {selectedDate}
          </Button>
        </section>

        <section className="space-y-3">
          <h3 className="text-lg font-medium text-gray-700">Period</h3>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {["1", "2", "3", "4", "5", "6"].map((period) => (
              <Button
                key={period}
                variant={selectedPeriod === period ? "default" : "outline"}
                onClick={() => setSelectedPeriod(period)}
                className={cn(
                  "min-w-[50px] px-4 py-2 rounded-full shadow-sm",
                  selectedPeriod === period
                    ? "bg-primary text-primary-foreground"
                    : "bg-white text-gray-700 border-gray-300 hover:bg-gray-100",
                )}
              >
                {period}
              </Button>
            ))}
          </div>
        </section>

        <section className="space-y-3">
          <h3 className="text-lg font-medium text-gray-700">Subject</h3>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {mockSubjects.map((subject) => (
              <Button
                key={subject.id}
                variant={selectedSubject === subject.id ? "default" : "outline"}
                onClick={() => setSelectedSubject(subject.id)}
                className={cn(
                  "px-4 py-2 rounded-full shadow-sm whitespace-nowrap",
                  selectedSubject === subject.id
                    ? "bg-primary text-primary-foreground"
                    : "bg-white text-gray-700 border-gray-300 hover:bg-gray-100",
                )}
              >
                {subject.name}
              </Button>
            ))}
          </div>
        </section>

        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium text-gray-700">Attendance</h3>
            <Button variant="outline" className="px-3 py-1 text-sm rounded-full bg-transparent" onClick={handleMarkAll}>
              <Check className="h-4 w-4 mr-1" /> Mark all
            </Button>
          </div>
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="grid grid-cols-[0.5fr_1.5fr_1fr] gap-4 p-4 border-b text-sm font-semibold text-gray-600">
              <div>Roll No</div>
              <div>Name</div>
              <div className="text-right">Is Present?</div>
            </div>
            {mockStudents.map((student) => (
              <div
                key={student.id}
                className="grid grid-cols-[0.5fr_1.5fr_1fr] gap-4 p-4 border-b last:border-b-0 items-center"
              >
                <div className="font-semibold text-gray-800">{student.rollNo}</div>
                <div>
                  <p className="font-medium text-gray-800">{student.name}</p>
                  <p className="text-xs text-gray-500">{student.regNo}</p>
                </div>
                <div className="flex justify-end">
                  <Checkbox
                    checked={attendance[student.id] || false}
                    onCheckedChange={(checked) => handleAttendanceChange(student.id, checked as boolean)}
                    className="h-6 w-6 rounded-md border-gray-400 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground"
                  />
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
      <Fab icon="check" onClick={handleSubmit} />
    </div>
  )
}
