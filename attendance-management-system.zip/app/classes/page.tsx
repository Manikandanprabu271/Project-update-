import Link from "next/link"
import { Header } from "@/components/header"
import { Card } from "@/components/ui/card"
import { CalendarDays, Newspaper, FileText } from "lucide-react"
import { mockStudents } from "@/lib/data"

export default function ClassDashboardPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header title="E37B" backHref="/" showMore />
      <main className="flex-1 p-4 space-y-6">
        <Card className="p-4 rounded-lg shadow-sm bg-white text-center">
          <h3 className="text-sm text-gray-500 mb-1">ACADEMIC YEAR</h3>
          <p className="text-lg font-semibold text-gray-800">2025-2026</p>
        </Card>

        <section className="space-y-3">
          <h3 className="text-lg font-medium text-gray-700">Quick Links</h3>
          <div className="grid grid-cols-3 gap-4">
            <Link
              href="/classes/news"
              className="flex flex-col items-center justify-center p-4 bg-white rounded-lg shadow-sm text-center hover:bg-gray-100 transition-colors"
            >
              <Newspaper className="h-8 w-8 text-primary mb-2" />
              <span className="text-sm font-medium text-gray-700">News</span>
            </Link>
            <Link
              href="/classes/attendance/edit"
              className="flex flex-col items-center justify-center p-4 bg-white rounded-lg shadow-sm text-center hover:bg-gray-100 transition-colors"
            >
              <CalendarDays className="h-8 w-8 text-primary mb-2" />
              <span className="text-sm font-medium text-gray-700">Attendance</span>
            </Link>
            <Link
              href="/classes/onduty/apply"
              className="flex flex-col items-center justify-center p-4 bg-white rounded-lg shadow-sm text-center hover:bg-gray-100 transition-colors"
            >
              <FileText className="h-8 w-8 text-primary mb-2" />
              <span className="text-sm font-medium text-gray-700">OnDuty Applications</span>
            </Link>
          </div>
        </section>

        <section className="space-y-3">
          <h3 className="text-lg font-medium text-gray-700">Classmates</h3>
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            {mockStudents.map((student, index) => (
              <Link
                href={`/classes/attendance/summary/${student.id}`}
                key={student.id}
                className="flex items-center p-4 border-b last:border-b-0 hover:bg-gray-50 transition-colors"
              >
                <div className="w-10 text-center font-semibold text-gray-800">{student.rollNo}</div>
                <div className="ml-4 flex-1">
                  <p className="font-medium text-gray-800">{student.name}</p>
                  <p className="text-sm text-gray-600">
                    {student.regNo} ({student.studentId})
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </section>
      </main>
    </div>
  )
}
