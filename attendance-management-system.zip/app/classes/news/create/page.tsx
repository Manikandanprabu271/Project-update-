import { Header } from "@/components/header"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Type, AlignLeft } from "lucide-react"

export default function NewsCreatePage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header title="News Create" backHref="/classes/news" />
      <main className="flex-1 p-4 space-y-6">
        <div className="space-y-4 bg-white p-4 rounded-lg shadow-sm">
          <div className="flex items-center gap-3">
            <Type className="h-5 w-5 text-gray-500" />
            <Input
              placeholder="Set Title"
              className="flex-1 border-0 focus-visible:ring-0 focus-visible:ring-offset-0 text-lg font-semibold"
            />
          </div>
          <div className="flex items-start gap-3">
            <AlignLeft className="h-5 w-5 text-gray-500 mt-2" />
            <Textarea
              placeholder="Description"
              className="flex-1 border-0 focus-visible:ring-0 focus-visible:ring-offset-0 min-h-[100px]"
            />
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="text-lg font-medium text-gray-700">Type</h3>
          <Select defaultValue="circular">
            <SelectTrigger className="w-full bg-white rounded-lg shadow-sm">
              <SelectValue placeholder="Select type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="circular">Circular</SelectItem>
              <SelectItem value="event">Event</SelectItem>
              <SelectItem value="announcement">Announcement</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button className="w-full py-6 text-lg rounded-lg bg-primary text-primary-foreground shadow-md hover:bg-primary/90">
          Create News
        </Button>
      </main>
    </div>
  )
}
