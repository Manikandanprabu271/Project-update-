import { Header } from "@/components/header"
import { Fab } from "@/components/fab"
import Link from "next/link"

export default function ClassNewsPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header title="Class News" backHref="/classes" />
      <main className="flex-1 p-4 flex items-center justify-center text-gray-600">No news available</main>
      <Link href="/classes/news/create">
        <Fab icon="plus" />
      </Link>
    </div>
  )
}
