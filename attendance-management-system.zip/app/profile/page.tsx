"use client"

import type React from "react"

import { useState } from "react"
import { Header } from "@/components/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { mockUserProfile } from "@/lib/data"

export default function ProfilePage() {
  const [profile, setProfile] = useState(mockUserProfile)
  const [isEditing, setIsEditing] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target
    setProfile((prev) => ({ ...prev, [id]: value }))
  }

  const handleSave = () => {
    console.log("Saving profile:", profile)
    // In a real application, you would send this data to your backend
    setIsEditing(false)
    alert("Profile updated successfully!")
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header title="My Profile" backHref="/" />
      <main className="flex-1 p-4 space-y-6">
        <Card className="p-4 rounded-lg shadow-sm bg-white">
          <CardHeader className="pb-4">
            <CardTitle className="text-xl font-semibold text-gray-800">Personal Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid w-full items-center gap-1.5">
              <Label htmlFor="name" className="text-gray-700">
                Name
              </Label>
              <Input
                type="text"
                id="name"
                value={profile.name}
                onChange={handleChange}
                readOnly={!isEditing}
                className="bg-gray-100 border-gray-200"
              />
            </div>
            <div className="grid w-full items-center gap-1.5">
              <Label htmlFor="email" className="text-gray-700">
                Email
              </Label>
              <Input
                type="email"
                id="email"
                value={profile.email}
                onChange={handleChange}
                readOnly={!isEditing}
                className="bg-gray-100 border-gray-200"
              />
            </div>
            <div className="grid w-full items-center gap-1.5">
              <Label htmlFor="rollNo" className="text-gray-700">
                Roll No
              </Label>
              <Input type="text" id="rollNo" value={profile.rollNo} readOnly className="bg-gray-100 border-gray-200" />
            </div>
            <div className="grid w-full items-center gap-1.5">
              <Label htmlFor="regNo" className="text-gray-700">
                Registration No
              </Label>
              <Input type="text" id="regNo" value={profile.regNo} readOnly className="bg-gray-100 border-gray-200" />
            </div>
            <div className="grid w-full items-center gap-1.5">
              <Label htmlFor="studentId" className="text-gray-700">
                Student ID
              </Label>
              <Input
                type="text"
                id="studentId"
                value={profile.studentId}
                readOnly
                className="bg-gray-100 border-gray-200"
              />
            </div>
            <div className="grid w-full items-center gap-1.5">
              <Label htmlFor="academicYear" className="text-gray-700">
                Academic Year
              </Label>
              <Input
                type="text"
                id="academicYear"
                value={profile.academicYear}
                readOnly
                className="bg-gray-100 border-gray-200"
              />
            </div>
            <div className="grid w-full items-center gap-1.5">
              <Label htmlFor="branch" className="text-gray-700">
                Branch
              </Label>
              <Input type="text" id="branch" value={profile.branch} readOnly className="bg-gray-100 border-gray-200" />
            </div>
            {isEditing ? (
              <Button
                onClick={handleSave}
                className="w-full mt-4 bg-primary text-primary-foreground hover:bg-primary/90"
              >
                Save Changes
              </Button>
            ) : (
              <Button
                onClick={() => setIsEditing(true)}
                className="w-full mt-4 bg-secondary text-secondary-foreground hover:bg-secondary/90"
              >
                Edit Profile
              </Button>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
